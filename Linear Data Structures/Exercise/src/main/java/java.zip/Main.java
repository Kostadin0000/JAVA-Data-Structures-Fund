import implementations.ArrayDeque;

import java.util.LinkedList;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {

        ArrayDeque ar = new ArrayDeque();
        ar.add(1);
        ar.add(2);
        ar.add(3);
        ar.add(4);
        ar.remove(2);
        System.out.println();
    }
}
